class Chef
  class Provider
    class RubyRvmBash < Chef::Provider::RubyRvmScript
    end
  end
end
