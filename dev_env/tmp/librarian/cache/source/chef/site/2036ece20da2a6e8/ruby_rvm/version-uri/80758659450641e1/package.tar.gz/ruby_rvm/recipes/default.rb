include_recipe 'ruby_rvm::rvm'
include_recipe 'ruby_rvm::rubies'
include_recipe 'ruby_rvm::gems'
include_recipe 'ruby_rvm::wrappers'
