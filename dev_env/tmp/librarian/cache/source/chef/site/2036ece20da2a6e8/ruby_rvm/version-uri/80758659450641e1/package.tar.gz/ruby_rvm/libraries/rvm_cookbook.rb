unless defined?(MIN_SUPPORTED_VERSION)
  class RvmCookbook
    MIN_SUPPORTED_VERSION = '11.12.0'
  end
end
