# Defaults for kalibro-configurations initscript
# sourced by /etc/init.d/kalibro-configurations
# installed at /etc/default/kalibro-configurations by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
