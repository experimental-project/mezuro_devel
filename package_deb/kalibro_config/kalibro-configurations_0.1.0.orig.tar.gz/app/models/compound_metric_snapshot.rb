class CompoundMetricSnapshot < MetricSnapshot
end
