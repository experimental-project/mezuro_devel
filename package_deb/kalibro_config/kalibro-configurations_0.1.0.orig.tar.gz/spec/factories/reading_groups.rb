FactoryGirl.define do
  factory :reading_group do
    id 7
    name "My reading group"
    description "My reading group description"
  end
end
